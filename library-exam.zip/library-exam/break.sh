#!/bin/bash
# SIMULATEUR D'INCIDENT — à lancer seulement quand l'application fonctionne.
# Ne lisez pas ce fichier avant d'avoir terminé le dépannage.
services=(books members loans)
svc=${services[$RANDOM % 3]}
fault=$((RANDOM % 4))
BASE=(-e DB_PORT=3306)

docker rm -f "$svc" >/dev/null 2>&1
case $fault in
  0) docker run -d --name "$svc" --network library-network "${BASE[@]}" \
       -e DB_HOST=database -e DB_NAME=librarydb -e DB_USER=libraryuser \
       -e DB_PASSWORD='LibraryPass12' "library-$svc:1.0" >/dev/null ;;
  1) docker run -d --name "$svc" --network library-network "${BASE[@]}" \
       -e DB_HOST=db-server -e DB_NAME=librarydb -e DB_USER=libraryuser \
       -e DB_PASSWORD='LibraryPass123!' "library-$svc:1.0" >/dev/null ;;
  2) docker run -d --name "$svc" "${BASE[@]}" \
       -e DB_HOST=database -e DB_NAME=librarydb -e DB_USER=libraryuser \
       -e DB_PASSWORD='LibraryPass123!' "library-$svc:1.0" >/dev/null ;;
  3) docker run -d --name "$svc" --network library-network "${BASE[@]}" \
       -e DB_HOST=database -e DB_NAME=library -e DB_USER=libraryuser \
       -e DB_PASSWORD='LibraryPass123!' "library-$svc:1.0" >/dev/null ;;
esac
echo "Incident déclenché. Ouvrez http://localhost:8080 et dépannez !"
