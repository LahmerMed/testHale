import os
import sys
import pymysql
from flask import Flask, jsonify, request

app = Flask(__name__)


def get_conn():
    return pymysql.connect(
        host=os.environ["DB_HOST"],
        port=int(os.environ.get("DB_PORT", "3306")),
        user=os.environ["DB_USER"],
        password=os.environ["DB_PASSWORD"],
        database=os.environ["DB_NAME"],
        cursorclass=pymysql.cursors.DictCursor,
        autocommit=True,
        connect_timeout=5,
    )


def fail(exc):
    print(f"[loans] ERREUR: {exc}", file=sys.stderr, flush=True)
    return jsonify({"service": "loans", "error": str(exc)}), 500


@app.get("/health")
def health():
    return jsonify({"service": "loans", "status": "up"})


@app.get("/")
def list_loans():
    try:
        conn = get_conn()
        with conn.cursor() as cur:
            cur.execute(
                """SELECT l.id, m.name AS member, b.title AS book,
                          DATE_FORMAT(l.loan_date, '%%Y-%%m-%%d %%H:%%i') AS loan_date
                   FROM loans l
                   JOIN members m ON m.id = l.member_id
                   JOIN books b ON b.id = l.book_id
                   ORDER BY l.id DESC"""
            )
            rows = cur.fetchall()
        conn.close()
        return jsonify(rows)
    except Exception as exc:
        return fail(exc)


@app.post("/")
def add_loan():
    data = request.get_json(silent=True) or {}
    member_id, book_id = data.get("member_id"), data.get("book_id")
    if not member_id or not book_id:
        return jsonify({"error": "member_id et book_id sont obligatoires"}), 400
    try:
        conn = get_conn()
        with conn.cursor() as cur:
            cur.execute("INSERT INTO loans (member_id, book_id) VALUES (%s, %s)", (member_id, book_id))
            new_id = cur.lastrowid
        conn.close()
        return jsonify({"id": new_id, "member_id": member_id, "book_id": book_id}), 201
    except Exception as exc:
        return fail(exc)


if __name__ == "__main__":
    print("[loans] démarrage sur le port 5000", flush=True)
    app.run(host="0.0.0.0", port=5000)
