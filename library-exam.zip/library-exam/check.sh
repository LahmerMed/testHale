#!/bin/bash
# Vérifie l'application depuis l'hôte (via le frontend publié sur 8080)
ok=0
for api in books members loans; do
  code=$(curl -s -o /dev/null -w '%{http_code}' --max-time 5 http://localhost:8080/api/$api/)
  if [ "$code" = "200" ]; then echo "[ OK ] /api/$api/ -> $code"; else echo "[FAIL] /api/$api/ -> $code"; ok=1; fi
done
code=$(curl -s -o /dev/null -w '%{http_code}' --max-time 5 http://localhost:8080/)
if [ "$code" = "200" ]; then echo "[ OK ] frontend -> $code"; else echo "[FAIL] frontend -> $code"; ok=1; fi
echo "--- Ports publiés (seul le frontend doit apparaître) ---"
docker ps --format 'table {{.Names}}\t{{.Ports}}'
exit $ok
