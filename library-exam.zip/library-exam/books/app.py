import os
import sys
import pymysql
from flask import Flask, jsonify

app = Flask(__name__)


def get_conn():
    return pymysql.connect(
        host=os.environ["DB_HOST"],
        port=int(os.environ.get("DB_PORT", "3306")),
        user=os.environ["DB_USER"],
        password=os.environ["DB_PASSWORD"],
        database=os.environ["DB_NAME"],
        cursorclass=pymysql.cursors.DictCursor,
        connect_timeout=5,
    )


def fail(exc):
    print(f"[books] ERREUR: {exc}", file=sys.stderr, flush=True)
    return jsonify({"service": "books", "error": str(exc)}), 500


@app.get("/health")
def health():
    return jsonify({"service": "books", "status": "up"})


@app.get("/")
def list_books():
    try:
        conn = get_conn()
        with conn.cursor() as cur:
            cur.execute("SELECT id, title, author, year FROM books ORDER BY id")
            rows = cur.fetchall()
        conn.close()
        return jsonify(rows)
    except Exception as exc:
        return fail(exc)


if __name__ == "__main__":
    print("[books] démarrage sur le port 5000", flush=True)
    app.run(host="0.0.0.0", port=5000)
