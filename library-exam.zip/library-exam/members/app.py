import os
import sys
import pymysql
from flask import Flask, jsonify, request

app = Flask(__name__)


def get_conn():
    return pymysql.connect(
        host=os.environ["DB_HOST"],
        port=int(os.environ.get("DB_PORT", "3306")),
        user=os.environ["DB_USER"],
        password=os.environ["DB_PASSWORD"],
        database=os.environ["DB_NAME"],
        cursorclass=pymysql.cursors.DictCursor,
        autocommit=True,
        connect_timeout=5,
    )


def fail(exc):
    print(f"[members] ERREUR: {exc}", file=sys.stderr, flush=True)
    return jsonify({"service": "members", "error": str(exc)}), 500


@app.get("/health")
def health():
    return jsonify({"service": "members", "status": "up"})


@app.get("/")
def list_members():
    try:
        conn = get_conn()
        with conn.cursor() as cur:
            cur.execute("SELECT id, name, email FROM members ORDER BY id")
            rows = cur.fetchall()
        conn.close()
        return jsonify(rows)
    except Exception as exc:
        return fail(exc)


@app.post("/")
def add_member():
    data = request.get_json(silent=True) or {}
    name, email = data.get("name"), data.get("email")
    if not name or not email:
        return jsonify({"error": "name et email sont obligatoires"}), 400
    try:
        conn = get_conn()
        with conn.cursor() as cur:
            cur.execute("INSERT INTO members (name, email) VALUES (%s, %s)", (name, email))
            new_id = cur.lastrowid
        conn.close()
        return jsonify({"id": new_id, "name": name, "email": email}), 201
    except Exception as exc:
        return fail(exc)


if __name__ == "__main__":
    print("[members] démarrage sur le port 5000", flush=True)
    app.run(host="0.0.0.0", port=5000)
