#!/bin/bash
# Cleans old containers/network so you can redo the test from zero
docker rm -f frontend backend database 2>/dev/null
docker network rm app-network 2>/dev/null
sudo rm -rf /opt/docker-login
echo "Environment ready. Start with Question 1."
