# Examen pratique Docker — Mini bibliothèque

## Sujet
Vous devez conteneuriser une petite application de gestion de livres appelée **Mini Bibliothèque**.
L'application contient un frontend Nginx et trois microservices backend Python, qui partagent une base de données MySQL.

### Architecture
- **Nginx / Frontend** : sert l'interface web et distribue les requêtes API.
- **Books API** : affiche la liste des livres.
- **Members API** : ajoute et liste les membres.
- **Loans API** : enregistre et liste les emprunts.
- **MySQL** : stocke les livres, membres et emprunts.

## Travail demandé
1. Compléter les Dockerfiles fournis dans `frontend/`, `books/`, `members/`, `loans/` et `database/`.
2. Construire les images Docker.
3. Créer le réseau `library-network`.
4. Démarrer les conteneurs sur ce réseau avec les variables suivantes :

   **Base de données**
   ```
   MYSQL_ROOT_PASSWORD='RootPass123!'
   MYSQL_DATABASE='librarydb'
   MYSQL_USER='libraryuser'
   MYSQL_PASSWORD='LibraryPass123!'
   ```
   **books, loans, members**
   ```
   DB_HOST=database
   DB_PORT=3306
   DB_NAME=librarydb
   DB_USER=libraryuser
   DB_PASSWORD='LibraryPass123!'
   ```
5. Publier uniquement le frontend sur le port `8080` de l'hôte.
6. Tester l'application et les API graphiquement.
7. **Challenge final — Dépannage**
   Une API devient indisponible à la suite d'une erreur de configuration.
   Votre mission :
   - Diagnostiquer l'incident à l'aide de l'interface, des commandes Docker et des logs.
   - Identifier et corriger la cause du problème.
   - Rétablir le service sans reconstruire inutilement toutes les images.
   - Vérifier le bon fonctionnement de l'application.

## Conventions pour cet entraînement
- Noms des images attendus : `library-database:1.0`, `library-books:1.0`, `library-members:1.0`,
  `library-loans:1.0`, `library-frontend:1.0`.
- Noms des conteneurs : `database`, `books`, `members`, `loans`, `frontend`.
- Les fichiers `app.py`, `nginx.conf`, `index.html`, `init.sql` ne doivent pas être modifiés.

## Déroulement
1. Faites les étapes 1 à 6.
2. Vérifiez que tout fonctionne : `./check.sh`
3. Lancez l'incident : `./break.sh` (**ne lisez pas ce script avant**, il tire une panne au hasard).
4. Faites l'étape 7, puis relancez `./check.sh`.

Chronométrez-vous : visez moins de 45 minutes pour les étapes 1 à 6, et 15 minutes pour le dépannage.
