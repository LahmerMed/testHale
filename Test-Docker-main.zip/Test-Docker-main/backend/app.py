import os
from flask import Flask, request, jsonify

app = Flask(__name__)

@app.post("/api/login")
def login():
    d = request.get_json()
    if d.get("username") == os.environ["ADMIN_USERNAME"] and d.get("password") == os.environ["ADMIN_PASSWORD"]:
        return jsonify(message="Welcome to the application")
    return jsonify(message="Wrong credentials"), 401

app.run(host="0.0.0.0", port=5000)
