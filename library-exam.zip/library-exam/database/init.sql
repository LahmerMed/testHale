USE librarydb;

CREATE TABLE IF NOT EXISTS books (
  id INT AUTO_INCREMENT PRIMARY KEY,
  title VARCHAR(150) NOT NULL,
  author VARCHAR(100) NOT NULL,
  year INT
);

CREATE TABLE IF NOT EXISTS members (
  id INT AUTO_INCREMENT PRIMARY KEY,
  name VARCHAR(100) NOT NULL,
  email VARCHAR(150) NOT NULL
);

CREATE TABLE IF NOT EXISTS loans (
  id INT AUTO_INCREMENT PRIMARY KEY,
  member_id INT NOT NULL,
  book_id INT NOT NULL,
  loan_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

INSERT INTO books (title, author, year) VALUES
 ('Le Petit Prince', 'Antoine de Saint-Exupéry', 1943),
 ('L''Étranger', 'Albert Camus', 1942),
 ('Les Misérables', 'Victor Hugo', 1862),
 ('Germinal', 'Émile Zola', 1885),
 ('Candide', 'Voltaire', 1759);

INSERT INTO members (name, email) VALUES
 ('Amine Ben Salah', 'amine@example.com');
